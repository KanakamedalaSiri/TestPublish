define("userFrmMetricsController", {
    //Type your controller code here 
});
define("FrmMetricsControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_fce54278f8134f6e9dc7d4e9fdd2960c: function AS_Button_fce54278f8134f6e9dc7d4e9fdd2960c(eventobject) {
        var self = this;
        return sendCustomMetrics.call(this);
    },
    AS_Button_d4ce85892fe94bc1b55c71c62d747a52: function AS_Button_d4ce85892fe94bc1b55c71c62d747a52(eventobject) {
        var self = this;
        return setUserId.call(this);
    },
    AS_Button_h6e0658f9fda42e19c0ef858a54b1caf: function AS_Button_h6e0658f9fda42e19c0ef858a54b1caf(eventobject) {
        var self = this;
        return sendEvent.call(this);
    },
    AS_Button_f2655d16896c463db930ef2490abd124: function AS_Button_f2655d16896c463db930ef2490abd124(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "VanityWithIrisDW",
            "friendlyName": "Form1"
        });
        ntf.navigate();
    },
    AS_Button_a0c56e81113e4adb87777cf296cd5924: function AS_Button_a0c56e81113e4adb87777cf296cd5924(eventobject) {
        var self = this;
        return flushEvents.call(this);
    }
});
define("FrmMetricsController", ["userFrmMetricsController", "FrmMetricsControllerActions"], function() {
    var controller = require("userFrmMetricsController");
    var controllerActions = ["FrmMetricsControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
