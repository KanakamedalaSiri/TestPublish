define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Button0h3c59b650a504b = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0h3c59b650a504b",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_a58971b76be247e8a66ad02bb56d8207,
                "skin": "defBtnNormal",
                "text": "Manual Init",
                "top": "135dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0c99e87607cdb4c = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0c99e87607cdb4c",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_a5e764b909be48b2b7de2bbeda7077df,
                "skin": "defBtnNormal",
                "text": "Identity",
                "top": "228dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0g80cd6fddc7c40 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0g80cd6fddc7c40",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_g875ed8182124780a9040b02296fd710,
                "skin": "defBtnNormal",
                "text": "Integration",
                "top": "326dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0e6f0aec209d340 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0e6f0aec209d340",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_ab82db0210f84b81aec5b79da8fe4509,
                "skin": "defBtnNormal",
                "text": "Orchetration",
                "top": "419dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0j7f034b44a244d = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0j7f034b44a244d",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_j47dc19e8591418cb255c405bca8ce7d,
                "skin": "defBtnNormal",
                "text": "Object",
                "top": "520dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0d247b646b91748 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0d247b646b91748",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_ae4dd532677a4ec3838ec68657906349,
                "skin": "defBtnNormal",
                "text": "Rules",
                "top": "612dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0f932ec95061348 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0f932ec95061348",
                "isVisible": true,
                "left": "109dp",
                "onClick": controller.AS_Button_ga80dc2e14d34ca1992f1b5060bb6287,
                "skin": "defBtnNormal",
                "text": "Metrics",
                "top": "705dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Button0h3c59b650a504b, Button0c99e87607cdb4c, Button0g80cd6fddc7c40, Button0e6f0aec209d340, Button0j7f034b44a244d, Button0d247b646b91748, Button0f932ec95061348);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "VanityWithIris20"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});