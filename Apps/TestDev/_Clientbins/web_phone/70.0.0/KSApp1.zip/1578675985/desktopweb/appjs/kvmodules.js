/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RepoManagerConfig',[], function() {
    var repoMapping = {};
    return repoMapping;
})
;
require(['RepoManagerConfig'], function(){});

define("sparequirefileslist", function(){});

