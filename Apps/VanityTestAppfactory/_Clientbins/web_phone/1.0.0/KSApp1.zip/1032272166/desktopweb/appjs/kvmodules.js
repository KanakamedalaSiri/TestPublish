/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('Copy2VanityObjectSvc/vanityObject/MF_Config',[], function() {
    var mappings = {
        "id": "id",
        "name": "name",
    };
    Object.freeze(mappings);
    var typings = {
        "id": "string",
        "name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "Copy2VanityObjectSvc",
        tableName: "vanityObject"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('Copy2VanityObjectSvc/vanityObject/Model',[], function() {
    var BaseModel = voltmx.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "vanityObject",
        "objectService": "Copy2VanityObjectSvc"
    };
    var setterFunctions = {
        id: function(val, state) {
            context["field"] = "id";
            context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
            state['id'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        name: function(val, state) {
            context["field"] = "name";
            context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
            state['name'] = voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function vanityObject(defaultValues) {
        var privateState = {};
        context["field"] = "id";
        context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
        privateState.id = defaultValues ? (defaultValues["id"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["id"], context) : null) : null;
        context["field"] = "name";
        context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
        privateState.name = defaultValues ? (defaultValues["name"] ? voltmx.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "id": {
                get: function() {
                    context["field"] = "id";
                    context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.id, context);
                },
                set: function(val) {
                    setterFunctions['id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "name": {
                get: function() {
                    context["field"] = "name";
                    context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
                    return voltmx.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.name, context);
                },
                set: function(val) {
                    setterFunctions['name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.id = value ? (value["id"] ? value["id"] : null) : null;
            privateState.name = value ? (value["name"] ? value["name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(vanityObject);
    //Create new class level validator object
    BaseModel.Validator.call(vanityObject);
    var registerValidatorBackup = vanityObject.registerValidator;
    vanityObject.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (vanityObject.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    vanityObject.relations = relations;
    vanityObject.prototype.isValid = function() {
        return vanityObject.isValid(this);
    };
    vanityObject.prototype.objModelName = "vanityObject";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    vanityObject.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = voltmx.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        voltmx.mvc.util.ProcessorUtils.getMetadataForObject("Copy2VanityObjectSvc", "vanityObject", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    vanityObject.clone = function(objectToClone) {
        var clonedObj = new vanityObject();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return vanityObject;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RepoManagerConfig',[], function() {
    var repoMapping = {
        vanityObject: {
            model: "Copy2VanityObjectSvc/vanityObject/Model",
            config: "Copy2VanityObjectSvc/vanityObject/MF_Config",
            repository: "",
        },
    };
    return repoMapping;
})
;
require(['Copy2VanityObjectSvc/vanityObject/MF_Config','Copy2VanityObjectSvc/vanityObject/Model','RepoManagerConfig'], function(){});

define("sparequirefileslist", function(){});

