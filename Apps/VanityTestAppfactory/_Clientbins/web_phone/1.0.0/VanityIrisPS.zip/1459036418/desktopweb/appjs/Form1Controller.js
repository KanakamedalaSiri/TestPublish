define("userForm1Controller", {
    //Type your controller code here 
});
define("Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_a5e764b909be48b2b7de2bbeda7077df: function AS_Button_a5e764b909be48b2b7de2bbeda7077df(eventobject) {
        var self = this;
        return identityService.call(this);
    },
    AS_Button_ae4dd532677a4ec3838ec68657906349: function AS_Button_ae4dd532677a4ec3838ec68657906349(eventobject) {
        var self = this;
        return rulesService.call(this);
    },
    AS_Button_ab82db0210f84b81aec5b79da8fe4509: function AS_Button_ab82db0210f84b81aec5b79da8fe4509(eventobject) {
        var self = this;
        return orchestrationService.call(this);
    },
    AS_Button_ga80dc2e14d34ca1992f1b5060bb6287: function AS_Button_ga80dc2e14d34ca1992f1b5060bb6287(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "VanityWithIris2",
            "friendlyName": "FrmMetrics"
        });
        ntf.navigate();
    },
    AS_Button_g875ed8182124780a9040b02296fd710: function AS_Button_g875ed8182124780a9040b02296fd710(eventobject) {
        var self = this;
        return integrationService.call(this);
    },
    AS_Button_a58971b76be247e8a66ad02bb56d8207: function AS_Button_a58971b76be247e8a66ad02bb56d8207(eventobject) {
        var self = this;
        return manualInit.call(this);
    },
    AS_Button_j47dc19e8591418cb255c405bca8ce7d: function AS_Button_j47dc19e8591418cb255c405bca8ce7d(eventobject) {
        var self = this;
        return objectService.call(this);
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
