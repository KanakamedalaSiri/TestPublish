define("FrmMetrics", function() {
    return function(controller) {
        function addWidgetsFrmMetrics() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Button0e94bf9a1c36a4c = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0e94bf9a1c36a4c",
                "isVisible": true,
                "left": "65dp",
                "onClick": controller.AS_Button_f2655d16896c463db930ef2490abd124,
                "skin": "defBtnNormal",
                "text": "Back",
                "top": "98dp",
                "width": "190dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0b587826b446346 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0b587826b446346",
                "isVisible": true,
                "left": "147dp",
                "onClick": controller.AS_Button_d4ce85892fe94bc1b55c71c62d747a52,
                "skin": "defBtnNormal",
                "text": "setUserId",
                "top": "251dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0e1980c3a7e9145 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0e1980c3a7e9145",
                "isVisible": true,
                "left": "147dp",
                "onClick": controller.AS_Button_h6e0658f9fda42e19c0ef858a54b1caf,
                "skin": "defBtnNormal",
                "text": "sendEvent",
                "top": "335dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0b41f656683af4d = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0b41f656683af4d",
                "isVisible": true,
                "left": "147dp",
                "onClick": controller.AS_Button_fce54278f8134f6e9dc7d4e9fdd2960c,
                "skin": "defBtnNormal",
                "text": "sendCustomMetrics",
                "top": "420dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0gb6516cb24ff46 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0gb6516cb24ff46",
                "isVisible": true,
                "left": "147dp",
                "onClick": controller.AS_Button_a0c56e81113e4adb87777cf296cd5924,
                "skin": "defBtnNormal",
                "text": "flushEvents",
                "top": "510dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Button0e94bf9a1c36a4c, Button0b587826b446346, Button0e1980c3a7e9145, Button0b41f656683af4d, Button0gb6516cb24ff46);
        };
        return [{
            "addWidgets": addWidgetsFrmMetrics,
            "enabledForIdleTimeout": false,
            "id": "FrmMetrics",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "VanityWithIris2"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});